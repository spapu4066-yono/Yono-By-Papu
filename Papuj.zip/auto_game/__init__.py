"""Auto Game integration package."""
